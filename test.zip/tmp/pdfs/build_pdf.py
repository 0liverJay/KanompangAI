from pathlib import Path
import re, html, textwrap
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Image, Preformatted, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.platypus.tableofcontents import TableOfContents
ROOT=Path('/Users/apple/KanompangAI')
for name,file in [('Arial','Arial.ttf'),('ArialBold','Arial Bold.ttf'),('Mono','Courier New.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'/System/Library/Fonts/Supplemental/'+file))
pdfmetrics.registerFontFamily('Arial',normal='Arial',bold='ArialBold',italic='Arial',boldItalic='ArialBold')
W,H=A4; usable=W-88
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyCustom',fontName='Arial',fontSize=9.2,leading=13.3,spaceAfter=7,textColor=colors.HexColor('#273448')))
styles.add(ParagraphStyle(name='TitleCustom',fontName='ArialBold',fontSize=26,leading=32,spaceAfter=18,textColor=colors.HexColor('#152840')))
styles.add(ParagraphStyle(name='ChapterCustom',fontName='ArialBold',fontSize=20,leading=25,spaceAfter=18,textColor=colors.HexColor('#152840'),keepWithNext=True))
styles.add(ParagraphStyle(name='SectionCustom',fontName='ArialBold',fontSize=12.5,leading=16,spaceBefore=13,spaceAfter=7,textColor=colors.HexColor('#185C70'),keepWithNext=True))
styles.add(ParagraphStyle(name='SubCustom',fontName='ArialBold',fontSize=10.5,leading=14,spaceBefore=9,spaceAfter=6,keepWithNext=True))
styles.add(ParagraphStyle(name='CellCustom',fontName='Arial',fontSize=7.6,leading=10.3,textColor=colors.HexColor('#273448')))
styles.add(ParagraphStyle(name='CodeCustom',fontName='Mono',fontSize=7.3,leading=10,spaceAfter=8,backColor=colors.HexColor('#F1F4F7'),borderPadding=7))
styles.add(ParagraphStyle(name='BulletCustom',parent=styles['BodyCustom'],leftIndent=11,firstLineIndent=-8))
chapter_names=['Product Requirements','Design Specification','Technical Specification','Test Specification']
def clean(s):
    return s.translate(str.maketrans({'—':'-','–':'-','‑':'-','−':'-','×':'x','≤':'<=','≥':'>=','→':'->','└':'+','├':'+','│':'|','─':'-'}))
def markup(s):
    s=clean(s)
    s=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',s)
    s=html.escape(s)
    s=re.sub(r'`([^`]+)`',r'<font name="Mono">\1</font>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    return s
class Doc(SimpleDocTemplate):
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and f.style.name=='ChapterCustom':
            key='chapter'+str(self.page)
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(f.getPlainText(),key,0,False)
            self.notify('TOCEntry',(0,f.getPlainText(),self.page,key))
def footer(c,d):
    c.saveState(); c.setStrokeColor(colors.HexColor('#D8E1EA')); c.line(44,39,W-44,39)
    c.setFont('Arial',8); c.setFillColor(colors.HexColor('#697789'))
    c.drawString(44,25,'ULTIMATE BUDGETER  |  RECONSTRUCTION SPECIFICATION')
    c.drawRightString(W-44,25,str(d.page)); c.restoreState()
story=[]
story += [Spacer(1,100),Paragraph('ULTIMATE BUDGETER',styles['TitleCustom']),Paragraph('Complete Reconstruction Specification',styles['ChapterCustom']),Paragraph('Product / Design / Technical / Testing',styles['BodyCustom']),Spacer(1,22),Paragraph('Four English requirements documents combined into one reference for rebuilding the Android application with Codex.',styles['BodyCustom']),Paragraph('Source inspection date: November 17, 2026',styles['BodyCustom']),Spacer(1,30),Paragraph('Use all four parts together. This specification preserves the original business rules and distinguishes confirmed source behavior from runtime checks and optional improvements.',styles['BodyCustom']),PageBreak()]
# Do not index the cover subtitle.
story[2].style=ParagraphStyle('CoverSubtitle',parent=styles['ChapterCustom'])
story.append(Paragraph('Contents',styles['TitleCustom']))
toc=TableOfContents(); toc.levelStyles=[ParagraphStyle('TOC',fontName='Arial',fontSize=11,leading=17,spaceBefore=14,leftIndent=0)]
story += [toc,Spacer(1,24),Paragraph('Reading order: begin with Product Requirements, follow Design and Technical Specifications, and use the Test Specification as the acceptance checklist.',styles['BodyCustom'])]
for index,path in enumerate(sorted((ROOT/'docs/reconstruction').glob('*.md'))):
    story.append(PageBreak())
    story.append(Paragraph(f'Part {index+1} - {chapter_names[index]}',styles['ChapterCustom']))
    lines=path.read_text().splitlines(); i=1
    while i<len(lines):
        line=lines[i].strip()
        if not line: i+=1; continue
        if line.startswith('```'):
            block=[]; i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                block.extend(textwrap.wrap(clean(lines[i]),width=94,replace_whitespace=False,drop_whitespace=False) or ['']); i+=1
            story.append(Preformatted('\n'.join(block),styles['CodeCustom'])); i+=1; continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',x) for x in cells): rows.append(cells)
                i+=1
            n=len(rows[0]); weights=[]
            for col in range(n):
                lengths=[len(re.sub(r'`','',r[col])) for r in rows]
                weights.append(min(44,max(10,max(lengths)**.83)))
            widths=[usable*x/sum(weights) for x in weights]
            cells=[[Paragraph(markup(x),styles['CellCustom']) for x in row] for row in rows]
            table=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E3EDF2')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F6F8FA')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#B3C5D2'))]))
            story.extend([table,Spacer(1,9)]); continue
        if line.startswith('!['):
            m=re.match(r'!\[([^\]]*)\]\(([^)]+)\)',line)
            if m:
                img=Image(str((path.parent/m[2]).resolve())); scale=min(usable/img.imageWidth,310/img.imageHeight); img.drawWidth=img.imageWidth*scale; img.drawHeight=img.imageHeight*scale
                story.append(KeepTogether([img,Spacer(1,5),Paragraph(m[1],styles['BodyCustom'])]))
            i+=1; continue
        if line.startswith('## '): story.append(Paragraph(markup(line[3:]),styles['SectionCustom'])); i+=1; continue
        if line.startswith('### '): story.append(Paragraph(markup(line[4:]),styles['SubCustom'])); i+=1; continue
        if line.startswith('- '): story.append(Paragraph('- '+markup(line[2:]),styles['BulletCustom'])); i+=1; continue
        if re.match(r'^\d+\. ',line): story.append(Paragraph(markup(line),styles['BulletCustom'])); i+=1; continue
        para=[line[2:] if line.startswith('> ') else line]; i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#|\||```|!\[|- |\d+\. |>)',lines[i].strip()):
            para.append(lines[i].strip()); i+=1
        story.append(Paragraph(markup(' '.join(para)),styles['BodyCustom']))
out=ROOT/'output/pdf/Ultimate_Budgeter_Complete_Reconstruction_Specification.pdf'
doc=Doc(str(out),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=44,bottomMargin=53,title='Ultimate Budgeter - Complete Reconstruction Specification',author='Codex')
doc.multiBuild(story,onFirstPage=footer,onLaterPages=footer)
print(out)
