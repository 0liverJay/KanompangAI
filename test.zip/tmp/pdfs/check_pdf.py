import fitz
from PIL import Image,ImageOps,ImageDraw
from pathlib import Path
p=Path('output/pdf/Ultimate_Budgeter_Complete_Reconstruction_Specification.pdf')
d=fitz.open(p)
print('Pages:',len(d),'Bytes:',p.stat().st_size)
text='\n'.join(page.get_text() for page in d)
for required in ['Product Requirements','Design Specification','Technical Specification','Test Specification','E-09','V-11','Q-12','completion checklist']:
    assert required.lower() in text.lower(),required
for i,page in enumerate(d):
    page.get_pixmap(matrix=fitz.Matrix(1,1)).save(f'tmp/pdfs/page-{i+1:02}.png')
    for block in page.get_text('dict')['blocks']:
        if block['type']==0:
            x0,y0,x1,y1=block['bbox']
            assert x0>=20 and x1<=page.rect.width-20 and y0>=15 and y1<=page.rect.height-15,(i+1,block['bbox'])
for start in range(0,len(d),12):
    sheet=Image.new('RGB',(1000,4*380),'#CCD3DC'); draw=ImageDraw.Draw(sheet)
    for k in range(start,min(start+12,len(d))):
        im=Image.open(f'tmp/pdfs/page-{k+1:02}.png'); im.thumbnail((310,345))
        x=(k-start)%3*333+12; y=(k-start)//3*380+22
        sheet.paste(im,(x,y)); draw.text((x,y-17),f'Page {k+1}',fill='black')
    sheet.save(f'tmp/pdfs/contact-{start//12+1}.png')
print('All page text within margins; key sections and final test IDs present.')
